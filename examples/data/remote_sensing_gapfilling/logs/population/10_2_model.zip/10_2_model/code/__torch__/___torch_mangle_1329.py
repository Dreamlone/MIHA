class ConvNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_1316.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_1320.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_1324.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_1328.Sequential
  def forward(self: __torch__.___torch_mangle_1329.ConvNet,
    input: Tensor) -> Tensor:
    _0 = self.layer4
    _1 = self.layer3
    _2 = (self.layer2).forward((self.layer1).forward(input, ), )
    return (_0).forward((_1).forward(_2, ), )
