class ConvNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_2506.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_2510.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_2514.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_2518.Sequential
  def forward(self: __torch__.___torch_mangle_2519.ConvNet,
    input: Tensor) -> Tensor:
    _0 = self.layer4
    _1 = self.layer3
    _2 = (self.layer2).forward((self.layer1).forward(input, ), )
    return (_0).forward((_1).forward(_2, ), )
