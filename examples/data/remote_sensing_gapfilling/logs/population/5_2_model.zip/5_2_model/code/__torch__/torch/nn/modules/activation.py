class Tanh(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.Tanh,
    argument_1: Tensor) -> Tensor:
    return torch.tanh(argument_1)
