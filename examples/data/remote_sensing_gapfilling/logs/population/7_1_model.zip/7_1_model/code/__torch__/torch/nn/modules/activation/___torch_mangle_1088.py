class ReLU6(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_1088.ReLU6,
    argument_1: Tensor) -> Tensor:
    return torch.hardtanh(argument_1, 0., 6.)
