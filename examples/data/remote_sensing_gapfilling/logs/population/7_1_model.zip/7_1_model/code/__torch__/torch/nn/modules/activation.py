class Hardshrink(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.Hardshrink,
    argument_1: Tensor) -> Tensor:
    return torch.hardshrink(argument_1, 0.5)
