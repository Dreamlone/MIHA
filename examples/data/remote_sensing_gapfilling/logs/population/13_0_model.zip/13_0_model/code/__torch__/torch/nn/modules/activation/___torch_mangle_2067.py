class Hardsigmoid(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_2067.Hardsigmoid,
    argument_1: Tensor) -> Tensor:
    return torch.hardsigmoid(argument_1)
