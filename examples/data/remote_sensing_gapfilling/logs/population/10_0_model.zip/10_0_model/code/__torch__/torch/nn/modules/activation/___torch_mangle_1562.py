class Hardshrink(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_1562.Hardshrink,
    argument_1: Tensor) -> Tensor:
    return torch.hardshrink(argument_1, 0.5)
