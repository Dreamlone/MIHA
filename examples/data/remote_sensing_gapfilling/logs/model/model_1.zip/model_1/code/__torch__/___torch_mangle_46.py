class ConvNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_32.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_36.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_40.Sequential
  drop_out : __torch__.torch.nn.modules.dropout.___torch_mangle_41.Dropout
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_45.Sequential
  def forward(self: __torch__.___torch_mangle_46.ConvNet,
    input: Tensor) -> Tensor:
    _0 = self.layer4
    _1 = self.drop_out
    _2 = self.layer3
    _3 = (self.layer2).forward((self.layer1).forward(input, ), )
    _4 = (_0).forward((_1).forward((_2).forward(_3, ), ), )
    return _4
