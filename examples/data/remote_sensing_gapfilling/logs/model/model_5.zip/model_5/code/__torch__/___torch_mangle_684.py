class ConvNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_671.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_675.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_679.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_683.Sequential
  def forward(self: __torch__.___torch_mangle_684.ConvNet,
    input: Tensor) -> Tensor:
    _0 = self.layer4
    _1 = self.layer3
    _2 = (self.layer2).forward((self.layer1).forward(input, ), )
    return (_0).forward((_1).forward(_2, ), )
