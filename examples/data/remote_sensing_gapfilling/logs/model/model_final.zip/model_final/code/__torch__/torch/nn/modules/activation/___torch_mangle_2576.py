class Hardtanh(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_2576.Hardtanh,
    argument_1: Tensor) -> Tensor:
    return torch.hardtanh(argument_1, -1., 1.)
