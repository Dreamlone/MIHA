class ConvNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  layer1 : __torch__.torch.nn.modules.container.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_3.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  drop_out : __torch__.torch.nn.modules.dropout.Dropout
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_10.Sequential
  def forward(self: __torch__.ConvNet,
    input: Tensor) -> Tensor:
    _0 = self.layer4
    _1 = self.drop_out
    _2 = self.layer3
    _3 = (self.layer2).forward((self.layer1).forward(input, ), )
    _4 = (_0).forward((_1).forward((_2).forward(_3, ), ), )
    return _4
